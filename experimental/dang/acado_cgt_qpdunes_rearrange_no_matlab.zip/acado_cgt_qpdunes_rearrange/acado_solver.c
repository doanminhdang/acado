/*
 *    This file was auto-generated using the ACADO Toolkit.
 *    
 *    While ACADO Toolkit is free software released under the terms of
 *    the GNU Lesser General Public License (LGPL), the generated code
 *    as such remains the property of the user who used ACADO Toolkit
 *    to generate this code. In particular, user dependent data of the code
 *    do not inherit the GNU LGPL license. On the other hand, parts of the
 *    generated code that are a direct copy of source code from the
 *    ACADO Toolkit or the software tools it is based on, remain, as derived
 *    work, automatically covered by the LGPL license.
 *    
 *    ACADO Toolkit is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *    
 */


#include "acado_common.h"


/******************************************************************************/
/*                                                                            */
/* qpDUNES interface data and functions                                       */
/*                                                                            */
/******************************************************************************/

#include <qpDUNES.h>

qpData_t    qpData;
qpOptions_t qpOptions;

#if 1
#define QPDUNES_LS_HOMOTOPY_GRID_SEARCH 0
#endif

int initializeQpDunes( void )
{
	return_t statusFlag;
	int kk;
	
	unsigned int nD[10 + 1]; for (kk = 0; kk < 10 + 1; nD[ kk++ ] = 0);
	
	qpOptions = qpDUNES_setupDefaultOptions();
	qpOptions.maxIter    = 54;
	qpOptions.printLevel = 2;
	qpOptions.stationarityTolerance = 1.e-6;
	qpOptions.regParam = 1.e-6;
	qpOptions.newtonHessDiagRegTolerance  = 1.e-8;
	qpOptions.lsType            = 1 ? QPDUNES_LS_ACCELERATED_GRADIENT_BISECTION_LS : QPDUNES_LS_HOMOTOPY_GRID_SEARCH;
/*	qpOptions.lsType			= QPDUNES_LS_BACKTRACKING_LS; */
	qpOptions.lineSearchReductionFactor	= 0.1;
	qpOptions.lineSearchMaxStepSize	= 1.;
	qpOptions.maxNumLineSearchIterations            = 25;
	qpOptions.maxNumLineSearchRefinementIterations  = 25;
/*	qpOptions.regType            = QPDUNES_REG_SINGULAR_DIRECTIONS; */
	qpOptions.regType            = QPDUNES_REG_LEVENBERG_MARQUARDT;

	qpDUNES_setup(&qpData, 10, 4, 1, nD, &( qpOptions ));
	
	for (kk = 0; kk < 10; ++kk)
	{
		qpData.intervals[ kk ]->H.sparsityType = 1 ? QPDUNES_DIAGONAL : QPDUNES_DENSE;
	}
	qpData.intervals[ 10 ]->H.sparsityType = 1 ? QPDUNES_DIAGONAL : QPDUNES_DENSE;
	
	statusFlag = qpDUNES_init(&qpData, acadoWorkspace.qpH, acadoWorkspace.qpG, acadoWorkspace.qpC, acadoWorkspace.qpc, acadoWorkspace.qpLb, acadoWorkspace.qpUb, 0, 0, 0);
	
	return (int)statusFlag;
}

void cleanupQpDunes( void )
{
	qpDUNES_cleanup( &qpData );
}

int solveQpDunes( void )
{
	return_t statusFlag;

	statusFlag = qpDUNES_updateData(&qpData, acadoWorkspace.qpH, acadoWorkspace.qpG, acadoWorkspace.qpC, acadoWorkspace.qpc, acadoWorkspace.qpLb, acadoWorkspace.qpUb, 0, 0, 0);
	if (statusFlag != QPDUNES_OK)
		return (int)statusFlag;

	if ( 1 )
		statusFlag = qpDUNES_updateIntervalData(&qpData, qpData.intervals[ 0 ], 0, 0, 0, 0, acadoWorkspace.qpLb0, acadoWorkspace.qpUb0, 0, 0, 0, 0);
	else
		statusFlag = qpDUNES_updateIntervalData(&qpData, qpData.intervals[ 10 ], 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
	if (statusFlag != QPDUNES_OK)
		return (int)statusFlag;

	statusFlag = qpDUNES_solve( &qpData );
	
	qpDUNES_getPrimalSol(&qpData, acadoWorkspace.qpPrimal);
	qpDUNES_getDualSol(&qpData, acadoWorkspace.qpLambda, acadoWorkspace.qpMu);
	
	return (int)statusFlag;
}


/******************************************************************************/
/*                                                                            */
/* ACADO code generation                                                      */
/*                                                                            */
/******************************************************************************/


int acado_modelSimulation(  )
{
int ret;

int lRun1;
ret = 0;
for (lRun1 = 0; lRun1 < 10; ++lRun1)
{
acadoWorkspace.state[0] = acadoVariables.x[lRun1 * 4];
acadoWorkspace.state[1] = acadoVariables.x[lRun1 * 4 + 1];
acadoWorkspace.state[2] = acadoVariables.x[lRun1 * 4 + 2];
acadoWorkspace.state[3] = acadoVariables.x[lRun1 * 4 + 3];

acadoWorkspace.state[24] = acadoVariables.u[lRun1];

ret = acado_integrate(acadoWorkspace.state, 1);

acadoWorkspace.d[lRun1 * 4] = acadoWorkspace.state[0] - acadoVariables.x[lRun1 * 4 + 4];
acadoWorkspace.d[lRun1 * 4 + 1] = acadoWorkspace.state[1] - acadoVariables.x[lRun1 * 4 + 5];
acadoWorkspace.d[lRun1 * 4 + 2] = acadoWorkspace.state[2] - acadoVariables.x[lRun1 * 4 + 6];
acadoWorkspace.d[lRun1 * 4 + 3] = acadoWorkspace.state[3] - acadoVariables.x[lRun1 * 4 + 7];

acadoWorkspace.evGx[lRun1 * 16] = acadoWorkspace.state[4];
acadoWorkspace.evGx[lRun1 * 16 + 1] = acadoWorkspace.state[5];
acadoWorkspace.evGx[lRun1 * 16 + 2] = acadoWorkspace.state[6];
acadoWorkspace.evGx[lRun1 * 16 + 3] = acadoWorkspace.state[7];
acadoWorkspace.evGx[lRun1 * 16 + 4] = acadoWorkspace.state[8];
acadoWorkspace.evGx[lRun1 * 16 + 5] = acadoWorkspace.state[9];
acadoWorkspace.evGx[lRun1 * 16 + 6] = acadoWorkspace.state[10];
acadoWorkspace.evGx[lRun1 * 16 + 7] = acadoWorkspace.state[11];
acadoWorkspace.evGx[lRun1 * 16 + 8] = acadoWorkspace.state[12];
acadoWorkspace.evGx[lRun1 * 16 + 9] = acadoWorkspace.state[13];
acadoWorkspace.evGx[lRun1 * 16 + 10] = acadoWorkspace.state[14];
acadoWorkspace.evGx[lRun1 * 16 + 11] = acadoWorkspace.state[15];
acadoWorkspace.evGx[lRun1 * 16 + 12] = acadoWorkspace.state[16];
acadoWorkspace.evGx[lRun1 * 16 + 13] = acadoWorkspace.state[17];
acadoWorkspace.evGx[lRun1 * 16 + 14] = acadoWorkspace.state[18];
acadoWorkspace.evGx[lRun1 * 16 + 15] = acadoWorkspace.state[19];

acadoWorkspace.evGu[lRun1 * 4] = acadoWorkspace.state[20];
acadoWorkspace.evGu[lRun1 * 4 + 1] = acadoWorkspace.state[21];
acadoWorkspace.evGu[lRun1 * 4 + 2] = acadoWorkspace.state[22];
acadoWorkspace.evGu[lRun1 * 4 + 3] = acadoWorkspace.state[23];
}
return ret;
}

void acado_evaluateLSQ(const real_t* in, real_t* out)
{
const real_t* xd = in;
const real_t* u = in + 4;

/* Compute outputs: */
out[0] = xd[0];
out[1] = xd[1];
out[2] = xd[2];
out[3] = xd[3];
out[4] = u[0];
}

void acado_evaluateLSQEndTerm(const real_t* in, real_t* out)
{
const real_t* xd = in;

/* Compute outputs: */
out[0] = xd[0];
out[1] = xd[1];
out[2] = xd[2];
out[3] = xd[3];
}

void acado_setStageH( real_t* const stageH, int index )
{
index = index;
stageH[0] = (real_t)1.0000000000000000e+00;
stageH[1] = 0.0;
stageH[2] = 0.0;
stageH[3] = 0.0;
stageH[5] = 0.0;
stageH[6] = (real_t)1.0000000000000000e+00;
stageH[7] = 0.0;
stageH[8] = 0.0;
stageH[10] = 0.0;
stageH[11] = 0.0;
stageH[12] = (real_t)1.0000000000000000e+00;
stageH[13] = 0.0;
stageH[15] = 0.0;
stageH[16] = 0.0;
stageH[17] = 0.0;
stageH[18] = (real_t)1.0000000000000000e+00;

stageH[24] = (real_t)1.0000000000000000e+00;
}

void acado_setStagef( real_t* const stagef, int index )
{
index = index;
stagef[0] = +acadoWorkspace.Dy[index * 5];
stagef[1] = +acadoWorkspace.Dy[index * 5 + 1];
stagef[2] = +acadoWorkspace.Dy[index * 5 + 2];
stagef[3] = +acadoWorkspace.Dy[index * 5 + 3];

stagef[4] = +acadoWorkspace.Dy[index * 5 + 4];
}

void acado_evaluateObjective(  )
{
int runObj;
for (runObj = 0; runObj < 10; ++runObj)
{
acadoWorkspace.objValueIn[0] = acadoVariables.x[runObj * 4];
acadoWorkspace.objValueIn[1] = acadoVariables.x[runObj * 4 + 1];
acadoWorkspace.objValueIn[2] = acadoVariables.x[runObj * 4 + 2];
acadoWorkspace.objValueIn[3] = acadoVariables.x[runObj * 4 + 3];
acadoWorkspace.objValueIn[4] = acadoVariables.u[runObj];

acado_evaluateLSQ( acadoWorkspace.objValueIn, acadoWorkspace.objValueOut );
acadoWorkspace.Dy[runObj * 5] = acadoWorkspace.objValueOut[0];
acadoWorkspace.Dy[runObj * 5 + 1] = acadoWorkspace.objValueOut[1];
acadoWorkspace.Dy[runObj * 5 + 2] = acadoWorkspace.objValueOut[2];
acadoWorkspace.Dy[runObj * 5 + 3] = acadoWorkspace.objValueOut[3];
acadoWorkspace.Dy[runObj * 5 + 4] = acadoWorkspace.objValueOut[4];

}
acadoWorkspace.objValueIn[0] = acadoVariables.x[40];
acadoWorkspace.objValueIn[1] = acadoVariables.x[41];
acadoWorkspace.objValueIn[2] = acadoVariables.x[42];
acadoWorkspace.objValueIn[3] = acadoVariables.x[43];
acado_evaluateLSQEndTerm( acadoWorkspace.objValueIn, acadoWorkspace.objValueOut );

acadoWorkspace.DyN[0] = acadoWorkspace.objValueOut[0];
acadoWorkspace.DyN[1] = acadoWorkspace.objValueOut[1];
acadoWorkspace.DyN[2] = acadoWorkspace.objValueOut[2];
acadoWorkspace.DyN[3] = acadoWorkspace.objValueOut[3];

}

void acado_evaluateConstraints(  )
{
int ind;
/** Column vector of size: 44 */
static const real_t lbXValues[ 44 ] = 
{ -1.0000000000000000e+12, 
-5.0000000000000000e-01, 
-1.0000000000000000e+12, 
-1.0000000000000000e+12, 
-1.0000000000000000e+12, 
-5.0000000000000000e-01, 
-1.0000000000000000e+12, 
-1.0000000000000000e+12, 
-1.0000000000000000e+12, 
-5.0000000000000000e-01, 
-1.0000000000000000e+12, 
-1.0000000000000000e+12, 
-1.0000000000000000e+12, 
-5.0000000000000000e-01, 
-1.0000000000000000e+12, 
-1.0000000000000000e+12, 
-1.0000000000000000e+12, 
-5.0000000000000000e-01, 
-1.0000000000000000e+12, 
-1.0000000000000000e+12, 
-1.0000000000000000e+12, 
-5.0000000000000000e-01, 
-1.0000000000000000e+12, 
-1.0000000000000000e+12, 
-1.0000000000000000e+12, 
-5.0000000000000000e-01, 
-1.0000000000000000e+12, 
-1.0000000000000000e+12, 
-1.0000000000000000e+12, 
-5.0000000000000000e-01, 
-1.0000000000000000e+12, 
-1.0000000000000000e+12, 
-1.0000000000000000e+12, 
-5.0000000000000000e-01, 
-1.0000000000000000e+12, 
-1.0000000000000000e+12, 
-1.0000000000000000e+12, 
-5.0000000000000000e-01, 
-1.0000000000000000e+12, 
-1.0000000000000000e+12, 
-1.0000000000000000e+12, 
-5.0000000000000000e-01, 
-1.0000000000000000e+12, 
-1.0000000000000000e+12 };
/** Column vector of size: 44 */
static const real_t ubXValues[ 44 ] = 
{ 1.0000000000000000e+12, 
1.5000000000000000e+00, 
1.0000000000000000e+12, 
1.0000000000000000e+12, 
1.0000000000000000e+12, 
1.5000000000000000e+00, 
1.0000000000000000e+12, 
1.0000000000000000e+12, 
1.0000000000000000e+12, 
1.5000000000000000e+00, 
1.0000000000000000e+12, 
1.0000000000000000e+12, 
1.0000000000000000e+12, 
1.5000000000000000e+00, 
1.0000000000000000e+12, 
1.0000000000000000e+12, 
1.0000000000000000e+12, 
1.5000000000000000e+00, 
1.0000000000000000e+12, 
1.0000000000000000e+12, 
1.0000000000000000e+12, 
1.5000000000000000e+00, 
1.0000000000000000e+12, 
1.0000000000000000e+12, 
1.0000000000000000e+12, 
1.5000000000000000e+00, 
1.0000000000000000e+12, 
1.0000000000000000e+12, 
1.0000000000000000e+12, 
1.5000000000000000e+00, 
1.0000000000000000e+12, 
1.0000000000000000e+12, 
1.0000000000000000e+12, 
1.5000000000000000e+00, 
1.0000000000000000e+12, 
1.0000000000000000e+12, 
1.0000000000000000e+12, 
1.5000000000000000e+00, 
1.0000000000000000e+12, 
1.0000000000000000e+12, 
1.0000000000000000e+12, 
1.5000000000000000e+00, 
1.0000000000000000e+12, 
1.0000000000000000e+12 };
/** Column vector of size: 10 */
static const real_t lbUValues[ 10 ] = 
{ -1.0000000000000000e+00, 
-1.0000000000000000e+00, 
-1.0000000000000000e+00, 
-1.0000000000000000e+00, 
-1.0000000000000000e+00, 
-1.0000000000000000e+00, 
-1.0000000000000000e+00, 
-1.0000000000000000e+00, 
-1.0000000000000000e+00, 
-1.0000000000000000e+00 };
/** Column vector of size: 10 */
static const real_t ubUValues[ 10 ] = 
{ 1.0000000000000000e+00, 
1.0000000000000000e+00, 
1.0000000000000000e+00, 
1.0000000000000000e+00, 
1.0000000000000000e+00, 
1.0000000000000000e+00, 
1.0000000000000000e+00, 
1.0000000000000000e+00, 
1.0000000000000000e+00, 
1.0000000000000000e+00 };
acadoWorkspace.qpLb0[4] = lbUValues[0] - acadoVariables.u[0];
acadoWorkspace.qpUb0[4] = ubUValues[0] - acadoVariables.u[0];
for (ind = 0; ind < 10; ++ind)
{
acadoWorkspace.qpLb[ind * 5] = lbXValues[ind * 4] - acadoVariables.x[ind * 4];
acadoWorkspace.qpLb[ind * 5 + 1] = lbXValues[ind * 4 + 1] - acadoVariables.x[ind * 4 + 1];
acadoWorkspace.qpLb[ind * 5 + 2] = lbXValues[ind * 4 + 2] - acadoVariables.x[ind * 4 + 2];
acadoWorkspace.qpLb[ind * 5 + 3] = lbXValues[ind * 4 + 3] - acadoVariables.x[ind * 4 + 3];
acadoWorkspace.qpLb[ind * 5 + 4] = lbUValues[ind] - acadoVariables.u[ind];
}
for (ind = 0; ind < 10; ++ind)
{
acadoWorkspace.qpUb[ind * 5] = ubXValues[ind * 4] - acadoVariables.x[ind * 4];
acadoWorkspace.qpUb[ind * 5 + 1] = ubXValues[ind * 4 + 1] - acadoVariables.x[ind * 4 + 1];
acadoWorkspace.qpUb[ind * 5 + 2] = ubXValues[ind * 4 + 2] - acadoVariables.x[ind * 4 + 2];
acadoWorkspace.qpUb[ind * 5 + 3] = ubXValues[ind * 4 + 3] - acadoVariables.x[ind * 4 + 3];
acadoWorkspace.qpUb[ind * 5 + 4] = ubUValues[ind] - acadoVariables.u[ind];
}

acadoWorkspace.qpLb[50] = lbXValues[40] - acadoVariables.x[40];
acadoWorkspace.qpLb[51] = lbXValues[41] - acadoVariables.x[41];
acadoWorkspace.qpLb[52] = lbXValues[42] - acadoVariables.x[42];
acadoWorkspace.qpLb[53] = lbXValues[43] - acadoVariables.x[43];
acadoWorkspace.qpUb[50] = ubXValues[40] - acadoVariables.x[40];
acadoWorkspace.qpUb[51] = ubXValues[41] - acadoVariables.x[41];
acadoWorkspace.qpUb[52] = ubXValues[42] - acadoVariables.x[42];
acadoWorkspace.qpUb[53] = ubXValues[43] - acadoVariables.x[43];

for (ind = 0; ind < 10; ++ind)
{
acadoWorkspace.qpC[ind * 20] = acadoWorkspace.evGx[ind * 16];
acadoWorkspace.qpC[ind * 20 + 1] = acadoWorkspace.evGx[ind * 16 + 1];
acadoWorkspace.qpC[ind * 20 + 2] = acadoWorkspace.evGx[ind * 16 + 2];
acadoWorkspace.qpC[ind * 20 + 3] = acadoWorkspace.evGx[ind * 16 + 3];
acadoWorkspace.qpC[ind * 20 + 5] = acadoWorkspace.evGx[ind * 16 + 4];
acadoWorkspace.qpC[ind * 20 + 6] = acadoWorkspace.evGx[ind * 16 + 5];
acadoWorkspace.qpC[ind * 20 + 7] = acadoWorkspace.evGx[ind * 16 + 6];
acadoWorkspace.qpC[ind * 20 + 8] = acadoWorkspace.evGx[ind * 16 + 7];
acadoWorkspace.qpC[ind * 20 + 10] = acadoWorkspace.evGx[ind * 16 + 8];
acadoWorkspace.qpC[ind * 20 + 11] = acadoWorkspace.evGx[ind * 16 + 9];
acadoWorkspace.qpC[ind * 20 + 12] = acadoWorkspace.evGx[ind * 16 + 10];
acadoWorkspace.qpC[ind * 20 + 13] = acadoWorkspace.evGx[ind * 16 + 11];
acadoWorkspace.qpC[ind * 20 + 15] = acadoWorkspace.evGx[ind * 16 + 12];
acadoWorkspace.qpC[ind * 20 + 16] = acadoWorkspace.evGx[ind * 16 + 13];
acadoWorkspace.qpC[ind * 20 + 17] = acadoWorkspace.evGx[ind * 16 + 14];
acadoWorkspace.qpC[ind * 20 + 18] = acadoWorkspace.evGx[ind * 16 + 15];
acadoWorkspace.qpC[ind * 20 + 4] = acadoWorkspace.evGu[ind * 4];
acadoWorkspace.qpC[ind * 20 + 9] = acadoWorkspace.evGu[ind * 4 + 1];
acadoWorkspace.qpC[ind * 20 + 14] = acadoWorkspace.evGu[ind * 4 + 2];
acadoWorkspace.qpC[ind * 20 + 19] = acadoWorkspace.evGu[ind * 4 + 3];
}

acadoWorkspace.qpc[0] = acadoWorkspace.d[0];
acadoWorkspace.qpc[1] = acadoWorkspace.d[1];
acadoWorkspace.qpc[2] = acadoWorkspace.d[2];
acadoWorkspace.qpc[3] = acadoWorkspace.d[3];
acadoWorkspace.qpc[4] = acadoWorkspace.d[4];
acadoWorkspace.qpc[5] = acadoWorkspace.d[5];
acadoWorkspace.qpc[6] = acadoWorkspace.d[6];
acadoWorkspace.qpc[7] = acadoWorkspace.d[7];
acadoWorkspace.qpc[8] = acadoWorkspace.d[8];
acadoWorkspace.qpc[9] = acadoWorkspace.d[9];
acadoWorkspace.qpc[10] = acadoWorkspace.d[10];
acadoWorkspace.qpc[11] = acadoWorkspace.d[11];
acadoWorkspace.qpc[12] = acadoWorkspace.d[12];
acadoWorkspace.qpc[13] = acadoWorkspace.d[13];
acadoWorkspace.qpc[14] = acadoWorkspace.d[14];
acadoWorkspace.qpc[15] = acadoWorkspace.d[15];
acadoWorkspace.qpc[16] = acadoWorkspace.d[16];
acadoWorkspace.qpc[17] = acadoWorkspace.d[17];
acadoWorkspace.qpc[18] = acadoWorkspace.d[18];
acadoWorkspace.qpc[19] = acadoWorkspace.d[19];
acadoWorkspace.qpc[20] = acadoWorkspace.d[20];
acadoWorkspace.qpc[21] = acadoWorkspace.d[21];
acadoWorkspace.qpc[22] = acadoWorkspace.d[22];
acadoWorkspace.qpc[23] = acadoWorkspace.d[23];
acadoWorkspace.qpc[24] = acadoWorkspace.d[24];
acadoWorkspace.qpc[25] = acadoWorkspace.d[25];
acadoWorkspace.qpc[26] = acadoWorkspace.d[26];
acadoWorkspace.qpc[27] = acadoWorkspace.d[27];
acadoWorkspace.qpc[28] = acadoWorkspace.d[28];
acadoWorkspace.qpc[29] = acadoWorkspace.d[29];
acadoWorkspace.qpc[30] = acadoWorkspace.d[30];
acadoWorkspace.qpc[31] = acadoWorkspace.d[31];
acadoWorkspace.qpc[32] = acadoWorkspace.d[32];
acadoWorkspace.qpc[33] = acadoWorkspace.d[33];
acadoWorkspace.qpc[34] = acadoWorkspace.d[34];
acadoWorkspace.qpc[35] = acadoWorkspace.d[35];
acadoWorkspace.qpc[36] = acadoWorkspace.d[36];
acadoWorkspace.qpc[37] = acadoWorkspace.d[37];
acadoWorkspace.qpc[38] = acadoWorkspace.d[38];
acadoWorkspace.qpc[39] = acadoWorkspace.d[39];

}

void acado_accumulate( real_t* const stageOut, int index )
{
acadoVariables.x[index * 4] += stageOut[0];
acadoVariables.x[index * 4 + 1] += stageOut[1];
acadoVariables.x[index * 4 + 2] += stageOut[2];
acadoVariables.x[index * 4 + 3] += stageOut[3];
acadoVariables.u[index] += stageOut[4];
}

int acado_preparationStep(  )
{
int ret;

ret = acado_modelSimulation();
acado_evaluateObjective(  );
acado_evaluateConstraints(  );
return ret;
}

int acado_feedbackStep(  )
{
int retVal;

acadoWorkspace.Dy[0] -= acadoVariables.y[0];
acadoWorkspace.Dy[1] -= acadoVariables.y[1];
acadoWorkspace.Dy[2] -= acadoVariables.y[2];
acadoWorkspace.Dy[3] -= acadoVariables.y[3];
acadoWorkspace.Dy[4] -= acadoVariables.y[4];
acadoWorkspace.Dy[5] -= acadoVariables.y[5];
acadoWorkspace.Dy[6] -= acadoVariables.y[6];
acadoWorkspace.Dy[7] -= acadoVariables.y[7];
acadoWorkspace.Dy[8] -= acadoVariables.y[8];
acadoWorkspace.Dy[9] -= acadoVariables.y[9];
acadoWorkspace.Dy[10] -= acadoVariables.y[10];
acadoWorkspace.Dy[11] -= acadoVariables.y[11];
acadoWorkspace.Dy[12] -= acadoVariables.y[12];
acadoWorkspace.Dy[13] -= acadoVariables.y[13];
acadoWorkspace.Dy[14] -= acadoVariables.y[14];
acadoWorkspace.Dy[15] -= acadoVariables.y[15];
acadoWorkspace.Dy[16] -= acadoVariables.y[16];
acadoWorkspace.Dy[17] -= acadoVariables.y[17];
acadoWorkspace.Dy[18] -= acadoVariables.y[18];
acadoWorkspace.Dy[19] -= acadoVariables.y[19];
acadoWorkspace.Dy[20] -= acadoVariables.y[20];
acadoWorkspace.Dy[21] -= acadoVariables.y[21];
acadoWorkspace.Dy[22] -= acadoVariables.y[22];
acadoWorkspace.Dy[23] -= acadoVariables.y[23];
acadoWorkspace.Dy[24] -= acadoVariables.y[24];
acadoWorkspace.Dy[25] -= acadoVariables.y[25];
acadoWorkspace.Dy[26] -= acadoVariables.y[26];
acadoWorkspace.Dy[27] -= acadoVariables.y[27];
acadoWorkspace.Dy[28] -= acadoVariables.y[28];
acadoWorkspace.Dy[29] -= acadoVariables.y[29];
acadoWorkspace.Dy[30] -= acadoVariables.y[30];
acadoWorkspace.Dy[31] -= acadoVariables.y[31];
acadoWorkspace.Dy[32] -= acadoVariables.y[32];
acadoWorkspace.Dy[33] -= acadoVariables.y[33];
acadoWorkspace.Dy[34] -= acadoVariables.y[34];
acadoWorkspace.Dy[35] -= acadoVariables.y[35];
acadoWorkspace.Dy[36] -= acadoVariables.y[36];
acadoWorkspace.Dy[37] -= acadoVariables.y[37];
acadoWorkspace.Dy[38] -= acadoVariables.y[38];
acadoWorkspace.Dy[39] -= acadoVariables.y[39];
acadoWorkspace.Dy[40] -= acadoVariables.y[40];
acadoWorkspace.Dy[41] -= acadoVariables.y[41];
acadoWorkspace.Dy[42] -= acadoVariables.y[42];
acadoWorkspace.Dy[43] -= acadoVariables.y[43];
acadoWorkspace.Dy[44] -= acadoVariables.y[44];
acadoWorkspace.Dy[45] -= acadoVariables.y[45];
acadoWorkspace.Dy[46] -= acadoVariables.y[46];
acadoWorkspace.Dy[47] -= acadoVariables.y[47];
acadoWorkspace.Dy[48] -= acadoVariables.y[48];
acadoWorkspace.Dy[49] -= acadoVariables.y[49];

acadoWorkspace.DyN[0] -= acadoVariables.yN[0];
acadoWorkspace.DyN[1] -= acadoVariables.yN[1];
acadoWorkspace.DyN[2] -= acadoVariables.yN[2];
acadoWorkspace.DyN[3] -= acadoVariables.yN[3];

acado_setStagef( acadoWorkspace.qpG, 0 );
acado_setStagef( &(acadoWorkspace.qpG[ 5 ]), 1 );
acado_setStagef( &(acadoWorkspace.qpG[ 10 ]), 2 );
acado_setStagef( &(acadoWorkspace.qpG[ 15 ]), 3 );
acado_setStagef( &(acadoWorkspace.qpG[ 20 ]), 4 );
acado_setStagef( &(acadoWorkspace.qpG[ 25 ]), 5 );
acado_setStagef( &(acadoWorkspace.qpG[ 30 ]), 6 );
acado_setStagef( &(acadoWorkspace.qpG[ 35 ]), 7 );
acado_setStagef( &(acadoWorkspace.qpG[ 40 ]), 8 );
acado_setStagef( &(acadoWorkspace.qpG[ 45 ]), 9 );
acadoWorkspace.qpG[50] = + (real_t)5.0000000000000000e+00*acadoWorkspace.DyN[0];
acadoWorkspace.qpG[51] = + (real_t)5.0000000000000000e+00*acadoWorkspace.DyN[1];
acadoWorkspace.qpG[52] = + (real_t)5.0000000000000000e+00*acadoWorkspace.DyN[2];
acadoWorkspace.qpG[53] = + (real_t)5.0000000000000000e+00*acadoWorkspace.DyN[3];

acadoWorkspace.qpLb0[0] = acadoVariables.x0[0] - acadoVariables.x[0];
acadoWorkspace.qpLb0[1] = acadoVariables.x0[1] - acadoVariables.x[1];
acadoWorkspace.qpLb0[2] = acadoVariables.x0[2] - acadoVariables.x[2];
acadoWorkspace.qpLb0[3] = acadoVariables.x0[3] - acadoVariables.x[3];
acadoWorkspace.qpUb0[0] = acadoWorkspace.qpLb0[0];
acadoWorkspace.qpUb0[1] = acadoWorkspace.qpLb0[1];
acadoWorkspace.qpUb0[2] = acadoWorkspace.qpLb0[2];
acadoWorkspace.qpUb0[3] = acadoWorkspace.qpLb0[3];

retVal = solveQpDunes();
acado_accumulate( acadoWorkspace.qpPrimal, 0 );
acado_accumulate( &(acadoWorkspace.qpPrimal[ 5 ]), 1 );
acado_accumulate( &(acadoWorkspace.qpPrimal[ 10 ]), 2 );
acado_accumulate( &(acadoWorkspace.qpPrimal[ 15 ]), 3 );
acado_accumulate( &(acadoWorkspace.qpPrimal[ 20 ]), 4 );
acado_accumulate( &(acadoWorkspace.qpPrimal[ 25 ]), 5 );
acado_accumulate( &(acadoWorkspace.qpPrimal[ 30 ]), 6 );
acado_accumulate( &(acadoWorkspace.qpPrimal[ 35 ]), 7 );
acado_accumulate( &(acadoWorkspace.qpPrimal[ 40 ]), 8 );
acado_accumulate( &(acadoWorkspace.qpPrimal[ 45 ]), 9 );

acadoVariables.x[40] += acadoWorkspace.qpPrimal[50];
acadoVariables.x[41] += acadoWorkspace.qpPrimal[51];
acadoVariables.x[42] += acadoWorkspace.qpPrimal[52];
acadoVariables.x[43] += acadoWorkspace.qpPrimal[53];

return retVal;
}

int acado_initializeSolver(  )
{
int ret;

/* This is a function which must be called once before any other function call! */


ret = 0;

memset(&acadoWorkspace, 0, sizeof( acadoWorkspace ));
ret = (int)initializeQpDunes();
if ((return_t)ret != QPDUNES_OK) return ret;
acado_setStageH( acadoWorkspace.qpH, 0 );
acado_setStageH( &(acadoWorkspace.qpH[ 25 ]), 1 );
acado_setStageH( &(acadoWorkspace.qpH[ 50 ]), 2 );
acado_setStageH( &(acadoWorkspace.qpH[ 75 ]), 3 );
acado_setStageH( &(acadoWorkspace.qpH[ 100 ]), 4 );
acado_setStageH( &(acadoWorkspace.qpH[ 125 ]), 5 );
acado_setStageH( &(acadoWorkspace.qpH[ 150 ]), 6 );
acado_setStageH( &(acadoWorkspace.qpH[ 175 ]), 7 );
acado_setStageH( &(acadoWorkspace.qpH[ 200 ]), 8 );
acado_setStageH( &(acadoWorkspace.qpH[ 225 ]), 9 );

acadoWorkspace.qpH[250] = (real_t)5.0000000000000000e+00;
acadoWorkspace.qpH[251] = 0.0;
acadoWorkspace.qpH[252] = 0.0;
acadoWorkspace.qpH[253] = 0.0;
acadoWorkspace.qpH[254] = 0.0;
acadoWorkspace.qpH[255] = (real_t)5.0000000000000000e+00;
acadoWorkspace.qpH[256] = 0.0;
acadoWorkspace.qpH[257] = 0.0;
acadoWorkspace.qpH[258] = 0.0;
acadoWorkspace.qpH[259] = 0.0;
acadoWorkspace.qpH[260] = (real_t)5.0000000000000000e+00;
acadoWorkspace.qpH[261] = 0.0;
acadoWorkspace.qpH[262] = 0.0;
acadoWorkspace.qpH[263] = 0.0;
acadoWorkspace.qpH[264] = 0.0;
acadoWorkspace.qpH[265] = (real_t)5.0000000000000000e+00;
return ret;
}

void acado_initializeNodesByForwardSimulation(  )
{
int index;
for (index = 0; index < 10; ++index)
{
acadoWorkspace.state[0] = acadoVariables.x[index * 4];
acadoWorkspace.state[1] = acadoVariables.x[index * 4 + 1];
acadoWorkspace.state[2] = acadoVariables.x[index * 4 + 2];
acadoWorkspace.state[3] = acadoVariables.x[index * 4 + 3];
acadoWorkspace.state[24] = acadoVariables.u[index];

acado_integrate(acadoWorkspace.state, index == 0);

acadoVariables.x[index * 4 + 4] = acadoWorkspace.state[0];
acadoVariables.x[index * 4 + 5] = acadoWorkspace.state[1];
acadoVariables.x[index * 4 + 6] = acadoWorkspace.state[2];
acadoVariables.x[index * 4 + 7] = acadoWorkspace.state[3];
}
}

void acado_shiftStates( int strategy, real_t* const xEnd, real_t* const uEnd )
{
int index;
for (index = 0; index < 10; ++index)
{
acadoVariables.x[index * 4] = acadoVariables.x[index * 4 + 4];
acadoVariables.x[index * 4 + 1] = acadoVariables.x[index * 4 + 5];
acadoVariables.x[index * 4 + 2] = acadoVariables.x[index * 4 + 6];
acadoVariables.x[index * 4 + 3] = acadoVariables.x[index * 4 + 7];
}

if (strategy == 1 && xEnd != 0)
{
acadoVariables.x[40] = xEnd[0];
acadoVariables.x[41] = xEnd[1];
acadoVariables.x[42] = xEnd[2];
acadoVariables.x[43] = xEnd[3];
}
else if (strategy == 2) 
{
acadoWorkspace.state[0] = acadoVariables.x[40];
acadoWorkspace.state[1] = acadoVariables.x[41];
acadoWorkspace.state[2] = acadoVariables.x[42];
acadoWorkspace.state[3] = acadoVariables.x[43];
if (uEnd != 0)
{
acadoWorkspace.state[24] = uEnd[0];
}
else
{
acadoWorkspace.state[24] = acadoVariables.u[9];
}

acado_integrate(acadoWorkspace.state, 1);

acadoVariables.x[40] = acadoWorkspace.state[0];
acadoVariables.x[41] = acadoWorkspace.state[1];
acadoVariables.x[42] = acadoWorkspace.state[2];
acadoVariables.x[43] = acadoWorkspace.state[3];
}
}

void acado_shiftControls( real_t* const uEnd )
{
int index;
for (index = 0; index < 9; ++index)
{
acadoVariables.u[index] = acadoVariables.u[index + 1];
}

if (uEnd != 0)
{
acadoVariables.u[9] = uEnd[0];
}
}

real_t acado_getKKT(  )
{
real_t kkt;

int index;
int index2;
kkt = + acadoWorkspace.qpG[0]*acadoWorkspace.qpPrimal[0] + acadoWorkspace.qpG[1]*acadoWorkspace.qpPrimal[1] + acadoWorkspace.qpG[2]*acadoWorkspace.qpPrimal[2] + acadoWorkspace.qpG[3]*acadoWorkspace.qpPrimal[3] + acadoWorkspace.qpG[4]*acadoWorkspace.qpPrimal[4] + acadoWorkspace.qpG[5]*acadoWorkspace.qpPrimal[5] + acadoWorkspace.qpG[6]*acadoWorkspace.qpPrimal[6] + acadoWorkspace.qpG[7]*acadoWorkspace.qpPrimal[7] + acadoWorkspace.qpG[8]*acadoWorkspace.qpPrimal[8] + acadoWorkspace.qpG[9]*acadoWorkspace.qpPrimal[9] + acadoWorkspace.qpG[10]*acadoWorkspace.qpPrimal[10] + acadoWorkspace.qpG[11]*acadoWorkspace.qpPrimal[11] + acadoWorkspace.qpG[12]*acadoWorkspace.qpPrimal[12] + acadoWorkspace.qpG[13]*acadoWorkspace.qpPrimal[13] + acadoWorkspace.qpG[14]*acadoWorkspace.qpPrimal[14] + acadoWorkspace.qpG[15]*acadoWorkspace.qpPrimal[15] + acadoWorkspace.qpG[16]*acadoWorkspace.qpPrimal[16] + acadoWorkspace.qpG[17]*acadoWorkspace.qpPrimal[17] + acadoWorkspace.qpG[18]*acadoWorkspace.qpPrimal[18] + acadoWorkspace.qpG[19]*acadoWorkspace.qpPrimal[19] + acadoWorkspace.qpG[20]*acadoWorkspace.qpPrimal[20] + acadoWorkspace.qpG[21]*acadoWorkspace.qpPrimal[21] + acadoWorkspace.qpG[22]*acadoWorkspace.qpPrimal[22] + acadoWorkspace.qpG[23]*acadoWorkspace.qpPrimal[23] + acadoWorkspace.qpG[24]*acadoWorkspace.qpPrimal[24] + acadoWorkspace.qpG[25]*acadoWorkspace.qpPrimal[25] + acadoWorkspace.qpG[26]*acadoWorkspace.qpPrimal[26] + acadoWorkspace.qpG[27]*acadoWorkspace.qpPrimal[27] + acadoWorkspace.qpG[28]*acadoWorkspace.qpPrimal[28] + acadoWorkspace.qpG[29]*acadoWorkspace.qpPrimal[29] + acadoWorkspace.qpG[30]*acadoWorkspace.qpPrimal[30] + acadoWorkspace.qpG[31]*acadoWorkspace.qpPrimal[31] + acadoWorkspace.qpG[32]*acadoWorkspace.qpPrimal[32] + acadoWorkspace.qpG[33]*acadoWorkspace.qpPrimal[33] + acadoWorkspace.qpG[34]*acadoWorkspace.qpPrimal[34] + acadoWorkspace.qpG[35]*acadoWorkspace.qpPrimal[35] + acadoWorkspace.qpG[36]*acadoWorkspace.qpPrimal[36] + acadoWorkspace.qpG[37]*acadoWorkspace.qpPrimal[37] + acadoWorkspace.qpG[38]*acadoWorkspace.qpPrimal[38] + acadoWorkspace.qpG[39]*acadoWorkspace.qpPrimal[39] + acadoWorkspace.qpG[40]*acadoWorkspace.qpPrimal[40] + acadoWorkspace.qpG[41]*acadoWorkspace.qpPrimal[41] + acadoWorkspace.qpG[42]*acadoWorkspace.qpPrimal[42] + acadoWorkspace.qpG[43]*acadoWorkspace.qpPrimal[43] + acadoWorkspace.qpG[44]*acadoWorkspace.qpPrimal[44] + acadoWorkspace.qpG[45]*acadoWorkspace.qpPrimal[45] + acadoWorkspace.qpG[46]*acadoWorkspace.qpPrimal[46] + acadoWorkspace.qpG[47]*acadoWorkspace.qpPrimal[47] + acadoWorkspace.qpG[48]*acadoWorkspace.qpPrimal[48] + acadoWorkspace.qpG[49]*acadoWorkspace.qpPrimal[49] + acadoWorkspace.qpG[50]*acadoWorkspace.qpPrimal[50] + acadoWorkspace.qpG[51]*acadoWorkspace.qpPrimal[51] + acadoWorkspace.qpG[52]*acadoWorkspace.qpPrimal[52] + acadoWorkspace.qpG[53]*acadoWorkspace.qpPrimal[53];
kkt = fabs( kkt );
for (index = 0; index < 40; ++index)
{
kkt+= fabs( acadoWorkspace.d[index] * acadoWorkspace.qpLambda[index]);
}
kkt += fabs(acadoWorkspace.qpLb0[0] * acadoWorkspace.qpMu[0]);
kkt += fabs(acadoWorkspace.qpUb0[0] * acadoWorkspace.qpMu[1]);
kkt += fabs(acadoWorkspace.qpLb0[1] * acadoWorkspace.qpMu[2]);
kkt += fabs(acadoWorkspace.qpUb0[1] * acadoWorkspace.qpMu[3]);
kkt += fabs(acadoWorkspace.qpLb0[2] * acadoWorkspace.qpMu[4]);
kkt += fabs(acadoWorkspace.qpUb0[2] * acadoWorkspace.qpMu[5]);
kkt += fabs(acadoWorkspace.qpLb0[3] * acadoWorkspace.qpMu[6]);
kkt += fabs(acadoWorkspace.qpUb0[3] * acadoWorkspace.qpMu[7]);
kkt += fabs(acadoWorkspace.qpLb0[4] * acadoWorkspace.qpMu[8]);
kkt += fabs(acadoWorkspace.qpUb0[4] * acadoWorkspace.qpMu[9]);
for (index = 1; index < 10; ++index)
{
for (index2 = 0; index2 < 5; ++index2)
{
kkt += fabs(acadoWorkspace.qpLb[(0) + (((index * 5) + (index2)) + (0))] * acadoWorkspace.qpMu[(((((index * 10) + (index2 * 2)) + (0)) + (0)) * (1)) + (0)]);
kkt += fabs(acadoWorkspace.qpUb[(0) + (((index * 5) + (index2)) + (0))] * acadoWorkspace.qpMu[(((((index * 10) + (index2 * 2)) + (1)) + (0)) * (1)) + (0)]);
}
}
kkt += fabs(acadoWorkspace.qpLb[50] * acadoWorkspace.qpMu[100]);
kkt += fabs(acadoWorkspace.qpUb[50] * acadoWorkspace.qpMu[101]);
kkt += fabs(acadoWorkspace.qpLb[51] * acadoWorkspace.qpMu[102]);
kkt += fabs(acadoWorkspace.qpUb[51] * acadoWorkspace.qpMu[103]);
kkt += fabs(acadoWorkspace.qpLb[52] * acadoWorkspace.qpMu[104]);
kkt += fabs(acadoWorkspace.qpUb[52] * acadoWorkspace.qpMu[105]);
kkt += fabs(acadoWorkspace.qpLb[53] * acadoWorkspace.qpMu[106]);
kkt += fabs(acadoWorkspace.qpUb[53] * acadoWorkspace.qpMu[107]);
return kkt;
}

real_t acado_getObjective(  )
{
real_t objVal;

int lRun1;
/** Row vector of size: 5 */
real_t tmpDy[ 5 ];

/** Row vector of size: 4 */
real_t tmpDyN[ 4 ];

for (lRun1 = 0; lRun1 < 10; ++lRun1)
{
acadoWorkspace.objValueIn[0] = acadoVariables.x[lRun1 * 4];
acadoWorkspace.objValueIn[1] = acadoVariables.x[lRun1 * 4 + 1];
acadoWorkspace.objValueIn[2] = acadoVariables.x[lRun1 * 4 + 2];
acadoWorkspace.objValueIn[3] = acadoVariables.x[lRun1 * 4 + 3];
acadoWorkspace.objValueIn[4] = acadoVariables.u[lRun1];

acado_evaluateLSQ( acadoWorkspace.objValueIn, acadoWorkspace.objValueOut );
acadoWorkspace.Dy[lRun1 * 5] = acadoWorkspace.objValueOut[0] - acadoVariables.y[lRun1 * 5];
acadoWorkspace.Dy[lRun1 * 5 + 1] = acadoWorkspace.objValueOut[1] - acadoVariables.y[lRun1 * 5 + 1];
acadoWorkspace.Dy[lRun1 * 5 + 2] = acadoWorkspace.objValueOut[2] - acadoVariables.y[lRun1 * 5 + 2];
acadoWorkspace.Dy[lRun1 * 5 + 3] = acadoWorkspace.objValueOut[3] - acadoVariables.y[lRun1 * 5 + 3];
acadoWorkspace.Dy[lRun1 * 5 + 4] = acadoWorkspace.objValueOut[4] - acadoVariables.y[lRun1 * 5 + 4];
}
acadoWorkspace.objValueIn[0] = acadoVariables.x[40];
acadoWorkspace.objValueIn[1] = acadoVariables.x[41];
acadoWorkspace.objValueIn[2] = acadoVariables.x[42];
acadoWorkspace.objValueIn[3] = acadoVariables.x[43];
acado_evaluateLSQEndTerm( acadoWorkspace.objValueIn, acadoWorkspace.objValueOut );
acadoWorkspace.DyN[0] = acadoWorkspace.objValueOut[0] - acadoVariables.yN[0];
acadoWorkspace.DyN[1] = acadoWorkspace.objValueOut[1] - acadoVariables.yN[1];
acadoWorkspace.DyN[2] = acadoWorkspace.objValueOut[2] - acadoVariables.yN[2];
acadoWorkspace.DyN[3] = acadoWorkspace.objValueOut[3] - acadoVariables.yN[3];
objVal = 0.0000000000000000e+00;
for (lRun1 = 0; lRun1 < 10; ++lRun1)
{
tmpDy[0] = + acadoWorkspace.Dy[lRun1 * 5];
tmpDy[1] = + acadoWorkspace.Dy[lRun1 * 5 + 1];
tmpDy[2] = + acadoWorkspace.Dy[lRun1 * 5 + 2];
tmpDy[3] = + acadoWorkspace.Dy[lRun1 * 5 + 3];
tmpDy[4] = + acadoWorkspace.Dy[lRun1 * 5 + 4];
objVal += + acadoWorkspace.Dy[lRun1 * 5]*tmpDy[0] + acadoWorkspace.Dy[lRun1 * 5 + 1]*tmpDy[1] + acadoWorkspace.Dy[lRun1 * 5 + 2]*tmpDy[2] + acadoWorkspace.Dy[lRun1 * 5 + 3]*tmpDy[3] + acadoWorkspace.Dy[lRun1 * 5 + 4]*tmpDy[4];
}

tmpDyN[0] = + acadoWorkspace.DyN[0]*(real_t)5.0000000000000000e+00;
tmpDyN[1] = + acadoWorkspace.DyN[1]*(real_t)5.0000000000000000e+00;
tmpDyN[2] = + acadoWorkspace.DyN[2]*(real_t)5.0000000000000000e+00;
tmpDyN[3] = + acadoWorkspace.DyN[3]*(real_t)5.0000000000000000e+00;
objVal += + acadoWorkspace.DyN[0]*tmpDyN[0] + acadoWorkspace.DyN[1]*tmpDyN[1] + acadoWorkspace.DyN[2]*tmpDyN[2] + acadoWorkspace.DyN[3]*tmpDyN[3];

objVal *= 0.5;
return objVal;
}

void acado_cleanupSolver(  )
{
cleanupQpDunes(  );
}

void acado_shiftQpData(  )
{
qpDUNES_shiftLambda( &qpData );
qpDUNES_shiftIntervals( &qpData );
}

